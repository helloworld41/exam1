package com.capgemini.tcc.service;

import com.capgemini.tcc.Exception.PatientDetails;
import com.capgemini.tcc.bean.PatientBean;

public interface IPatientService {
	
	public int addPatientDetails(PatientBean patient) throws PatientDetails;
	public PatientBean getPatientDetails(int patientId) throws PatientDetails;
	public boolean validatePatientName(String pname);
	public boolean validatePhoneNo(long phono);
	public boolean validatePatientId(int patientId);

}
