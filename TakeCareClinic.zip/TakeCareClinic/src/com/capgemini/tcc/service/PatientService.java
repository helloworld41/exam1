package com.capgemini.tcc.service;

import java.util.regex.Matcher;
import java.util.regex.Pattern;

import com.capgemini.tcc.Exception.InvalidPatientIdException;
import com.capgemini.tcc.bean.PatientBean;
import com.capgemini.tcc.dao.IPatientDAO;
import com.capgemini.tcc.dao.PatientDAO;

public class PatientService implements IPatientService {
	
	
	IPatientDAO dao=new PatientDAO();
	@Override
	public int addPatientDetails(PatientBean patient) {
		// TODO Auto-generated method stub
		
		dao.addPatientDetails(patient);
		return patient.getPatient_id();
	}

	@Override
	public PatientBean getPatientDetails(int patientId) {
		// TODO Auto-generated method stub
		return dao.getPatientDetails(patientId);
	}

	@Override
	public boolean validatePatientName(String pname) {
		// TODO Auto-generated method stub
		Pattern pattern= Pattern.compile("[A-Z][a-z]{1,19}");
		Matcher matcher= pattern.matcher(pname);
		return matcher.matches();
	}

	@Override
	public boolean validatePhoneNo(long phoneNo) {
		// TODO Auto-generated method stub
		String phno=Long.toString(phoneNo);
		Pattern pattern= Pattern.compile("[0-9]{10}");
		Matcher matcher= pattern.matcher(phno);
		return matcher.matches();
	}

	@Override
	public boolean validatePatientId(int patientId) {
		// TODO Auto-generated method stub
		PatientBean Patient=new PatientBean();
		if(patientId!=Patient.getPatient_id())
			try {
				throw new InvalidPatientIdException("There is no patient with this id ");
			} catch (InvalidPatientIdException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
		return true;
	}

	

}
