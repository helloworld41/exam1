package com.capgemini.tcc.ui;

import java.util.Scanner;

import com.capgemini.tcc.Exception.PatientDetails;
import com.capgemini.tcc.bean.PatientBean;
import com.capgemini.tcc.service.IPatientService;
import com.capgemini.tcc.service.PatientService;

public class Client {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		
		IPatientService service=new PatientService();
		
		Scanner scan = new Scanner(System.in);
		PatientBean patient=new PatientBean();
		
		do {
			System.out.println("Menu\n 1.Add PatientDetails");
			System.out.println("2.get PatientDetails");
			System.out.println("3.Exit");
			System.out.println("enter your choice");
			int choice = scan.nextInt();
			switch (choice) {
			case 1:
				do {
				System.out.println("Enter patient name:");
				String pname = scan.next();
				boolean res=service.validatePatientName(pname);
				if(res==true){
					patient.setPatient_name(pname);
					break;
				}else{
					System.out.println("Valid value should contain maximum 20 alphabets. Out of 20 Characters, first character should be in UPPERCASE");
				}
			}while(true);
				
				System.out.println("Enter age:");
				int age = scan.nextInt();
				patient.setAge(age);
				
				do {
				System.out.println("Enter phone number");
				long phono=scan.nextInt();
				boolean res=service.validatePhoneNo(phono);
				if(res==true){
					patient.setPhoneno(phono);
					break;
				}else{
					System.out.println("Valid value should contain 10 digits exactly. ");
				}
			}while(true);
				
				System.out.println("Enter description");
				String desc=scan.next();
				patient.setDescription(desc);
				
				
				
				try {
					int id=service.addPatientDetails(patient);
					System.out.println("successfully inserted"+id);
				} catch (PatientDetails e) {
					// TODO Auto-generated catch block
					e.printStackTrace();
				}
				
				break;
				
			case 2:
				System.out.println("Enter patient id to get patient details");
				int patientid=scan.nextInt();
				
				try {
					//service.getPatientDetails(patientid);
					System.out.println(service.getPatientDetails(patientid));
				} catch (PatientDetails e) {
					// TODO Auto-generated catch block
					e.printStackTrace();
				}
				
				
				break;
				
			case 3:
				System.exit(0);

			default:
				System.out.println("Invalid choice try again");
			}
		} while (true);


	
		}

}
