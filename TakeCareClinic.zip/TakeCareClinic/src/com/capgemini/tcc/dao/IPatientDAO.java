package com.capgemini.tcc.dao;

import com.capgemini.tcc.bean.PatientBean;

public interface IPatientDAO {
	
	public int addPatientDetails(PatientBean patient);
	public PatientBean getPatientDetails(int patientId);
	
	

}
