package com.capgemini.tcc.util;

import java.io.FileReader;
import java.sql.Connection;
import java.sql.DriverManager;
import java.util.Properties;



public class DBUtil {
	 //static Logger logger=Logger.getLogger(DBUtil.class);
		private static Connection connection;
		
		public static Connection getConnection(){
			//logger.info("start of getConnection method");
			if(connection==null){
			try{
				FileReader reader=new FileReader("Resources\\jdbc.properties");
				Properties properties=new Properties();
				properties.load(reader);
				Class.forName(properties.getProperty("driver"));
				connection=DriverManager.getConnection(properties.getProperty("url"),properties.getProperty("userName"),properties.getProperty("password"));

			}catch(Exception e){
				System.out.println(e.getMessage());
				//logger.error("problem occured while loading class"+e.getMessage());
			}
		}
			//logger.info("end of get connection");
			return connection;
		}
		public static void main(String[] args) {
			System.out.println(DBUtil.getConnection());
			System.out.println("/////////////////////////////");
			System.out.println(DBUtil.getConnection());
		}

}
